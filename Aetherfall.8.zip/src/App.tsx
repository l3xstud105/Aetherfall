import { useEffect, useRef } from 'react';
import { S, emitUI, loadSettings, useUI } from './game/store';
import { startGame } from './game/game';
import { net } from './game/net';
import { audio } from './game/audio';
import { Codex } from './ui/Codex';
import { Confirm, DeadScreen, Hud, PauseMenu } from './ui/Hud';
import { Creator, Ending, Intro, MainMenu, Settings } from './ui/Menus';
import { Dialogue, HouseEdit, HouseSale, Multiplayer, Shop, Stable, Storage } from './ui/Panels';
import { TipHost } from './ui/ui';

const TIPS = ['Press Space again in mid-air to glide. Aether updrafts carry you to the floating isles.', 'Crouch to sneak. Rogues are nearly invisible in shadow.', 'Reputation changes prices, dialogue and who will even speak to you.', 'Beds save your game. Own a home to craft at your own forge.', 'Companions never die — they retreat. Treat them well and they grow loyal.', 'The sky changes with the seasons. Moonpetals only bloom at night.'];

export default function App() {
  useUI(); const canvasRef = useRef<HTMLCanvasElement>(null); const booting = useRef(false); const joined = useRef(false);
  useEffect(() => { loadSettings(); emitUI(); const unlock = () => audio.init(); window.addEventListener('pointerdown', unlock, { once: true }); window.addEventListener('keydown', unlock, { once: true }); }, []);
  useEffect(() => {
    if (S.screen === 'boot' && !booting.current && canvasRef.current) { booting.current = true; startGame(canvasRef.current).catch((e) => { console.error(e); S.ui.loading = { pct: 0, text: 'Failed to start: ' + (e?.message || e) }; emitUI(); }).finally(() => { booting.current = false; }); }
    if (S.screen === 'game' && !joined.current) { joined.current = true; const code = new URLSearchParams(location.search).get('join'); if (code && net.status === 'offline') setTimeout(() => net.join(code), 800); }
  });
  const sc = S.screen; const ui = S.ui; const inGame = sc === 'game' || sc === 'ending';
  return (
    <div id="af-root" className={`${S.settings.contrast ? 'hc' : ''} ${S.settings.reduceMotion ? 'reduce' : ''}`} style={{ ['--scale' as any]: S.settings.uiScale }}>
      <canvas id="af-canvas" ref={canvasRef} tabIndex={-1} style={{ visibility: sc === 'game' || sc === 'boot' || sc === 'ending' ? 'visible' : 'hidden' }} />
      {inGame && <div id="af-grade" />}
      {sc === 'menu' && <MainMenu />}
      {sc === 'creator' && <Creator />}
      {sc === 'intro' && <Intro onDone={() => { S.screen = 'boot'; emitUI(); }} />}
      {sc === 'game' && <Hud />}
      {sc === 'game' && ui.codex && <Codex />}
      {sc === 'game' && ui.dialogue && <Dialogue />}
      {sc === 'game' && ui.shop && <Shop />}
      {sc === 'game' && ui.stable && <Stable />}
      {sc === 'game' && ui.houseSale && <HouseSale />}
      {sc === 'game' && ui.houseEdit && <HouseEdit />}
      {sc === 'game' && ui.storage && <Storage />}
      {sc === 'game' && ui.pause && <PauseMenu />}
      {sc === 'game' && ui.dead && <DeadScreen />}
      {ui.mp && <Multiplayer />}
      {sc === 'ending' && <Ending />}
      {ui.settings && <Settings />}
      <Confirm />
      {ui.loading && <div className="fixed inset-0 flex flex-col items-center justify-center gap-4 anim-fade" style={{ zIndex: 80, background: 'radial-gradient(ellipse at center, #1a1030, #04030a)' }}><div className="logo" style={{ fontSize: '3em' }}>AETHERFALL</div><div className="title">{ui.loading.text}</div><div className="bar" style={{ width: 360, height: 12 }}><i style={{ width: ui.loading.pct + '%', background: 'linear-gradient(90deg,#b8902a,#ffe27a)' }} /></div><div className="dim" style={{ maxWidth: 480, textAlign: 'center', fontSize: '0.9em' }}>{TIPS[Math.floor(ui.loading.pct / 17) % TIPS.length]}</div></div>}
      <TipHost />
    </div>
  );
}
