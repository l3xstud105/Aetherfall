# AETHERFALL 0.8 — A Tale of Broken Skies
**L3X STUD105** · browser-first 3D third-person open-world fantasy RPG (Three.js + React + WebAudio + PeerJS)

Play: `npm install && npm run build`, then open `dist/index.html` (single self-contained file). Dev: `npm run dev`.

---
## ⚠️ Honest project notes (read first)
* **The three reference URLs could not be inspected.** They serve only an empty "Built with Arena" app shell — no source, assets or save data are reachable from outside, and the workspace I was given was an empty template. So I could **not** preserve, merge or modify those prototypes. This repo is a **fresh, single, unified implementation** of the brief (story, ten classes, character creator, world, systems). Nothing here claims to be the old code.
* **Combat:** because the original combat could not be read, "the existing combat must be unchanged" could not apply. Combat here is a new, self-contained system (below). Gliding is implemented and working.
* **Graphics presets:** the first half of the brief asked to *remove* Low/Medium/High; the 0.8 half asks for **six real presets** (Low, Medium, High, Ultra, Cinematic, God). I implemented the six (the newest instruction) with **Cinematic as the default**. Each preset really changes render scale, shadow type/resolution, vegetation density, draw distances, particles, tone mapping, reflections, FOV, and CSS vignette/letter-box grading.
* **No GPU was available to me.** The sandbox had no browser libraries (no root, no apt). I could therefore **not** visually inspect frames, measure FPS, or test on a Chromebook/Firefox/Edge. Everything else was tested headlessly (see Tests). Visual polish and performance numbers are **unverified** — treat them as the main risk.
* **Audio is 100 % procedural** (WebAudio synthesis: music, ambience, SFX, voice blips). No recorded voice acting exists. Not listened to by me.
* **Multiplayer** is real WebRTC peer-to-peer (PeerJS) but was **not tested across two real browsers/networks** here (no network browser). It needs internet access to the free public PeerJS signalling service.

---
## Controls (all remappable in Settings → Controls)
| Action | Keyboard / mouse | Controller (Xbox/PS glyphs auto-detected) |
|---|---|---|
| Move / camera | WASD / mouse (click to capture), arrow keys also rotate | Left stick / Right stick |
| Jump, **Glide** (press again mid-air) | Space | A |
| Sprint / Crouch | Shift / C | RB / R3 |
| Attack / Block / Dodge | LMB / RMB or F / Q | X or RT / LT / B |
| Abilities 1-4 | 1 2 3 4 | D-pad |
| Interact | E | Y |
| Mount / dismount | R | R3 |
| Quick-heal | H | LB |
| Inventory / Skills / Journal / Map | I / K / J / M | View = map; menus: D-pad+A/B, LB/RB tabs |
| Emote / Chat | G / Enter | |
If pointer-lock is unavailable (embedded iframe) hold RMB and move the mouse, or use the arrow keys, to rotate the camera.

## What is implemented (all reachable in the real game)
* **Character creator** with live 3-D preview: name, build, height, skin, 7 hairstyles, hair/eye colours, facial hair, expression, accent/cape colour; **10 classes** (Warrior, Berserker, Archer, Mage, Rogue, Knight, Healer, Paladin, Hunter, Battlemage) each with attributes, starting gear, 2 starting abilities. Mirror furniture re-opens the creator in-game. Cinematic intro → Thornwick.
* **World** (520×520 m): 4 kingdoms' settlements — **Highcrown** (walled city, 4 gates, castle, plaza fountain, 44+ houses, market stalls, estate), **Thornwick** (timber village + farm + stables), **Frostgate** (walled mountain town + keep), **Saltmere** (harbour, pier, boats); ruined **Ashenvale**, **Spire ruins** (portal, updrafts), **Fort Cinderwatch**, **Hollowdeep Mine** (cave), **Glimmer Grove**, smugglers' cove, ruined chapel, lighthouse, waterfall cliff, rivers + bridges, lake, coast, **3 floating islands**. ~97 000 instanced plants/rocks (wind-animated), roads, seasons (7 in-game days each) and day/night.
* **Enterable interiors** (cut-away rooms): tavern, smithy, shop, alchemist, archive, great hall (throne), cave (rune puzzle → secret vault), Hollow Rift (boss arena dimension), and player homes (one is a split-level manor with a staircase).
* **Housing:** buy 4 properties (Cottage 400g, Townhouse 1 500g, Manor 5 000g, Royal Estate 15 000g), furnish with 19 furniture types (functional: beds save/restore, chests = storage, hearth/anvil/alchemy = real crafting stations, mirror, seats), move/rotate/store pieces, 3 upgrade levels (bigger rooms, more slots), storage chest. Ownership/furniture/storage persist in saves.
* **Multiplayer:** host/join by 6-letter code or `?join=CODE` invite link; see other players (names, class, gear), synced movement/animation/emotes/chat, shared time & weather, disconnect handling. Single-player is untouched.
* **Living world:** ~94 NPCs with schedules (work, wander, evening tavern, sleep indoors, shelter from rain, flee from combat, greet by reputation), guards patrolling; 220+ creatures: deer, wolves, foxes, bears, rabbits, boars, squirrels, wild horses, fantasy glimmerfoxes & aether stag, birds (songbirds, eagles, owls at night), fish, frogs. Prey flees, predators hunt, animals graze/rest.
* **Mounts:** Horse, Warhorse, Dire Wolf, Glimmerstag, Starmare (slow-fall). Bought or earned.
* **RPG systems:** levels 1-30, attributes, 5 skill branches (Might/Guile/Arcana/Spirit/Wild, 38 nodes, legendary tier, specialization titles; any class can learn anything), 19 abilities with different elements/VFX/audio, weapon/magic mastery, ~110 items with rarities, requirements, comparison, weight, bound-element weapons, equipment shown on the 3-D character.
* **Professions:** blacksmithing, alchemy, cooking (crafting stations), mining, herbalism, fishing (timing mini-game), hunting, farming (real-time crop growth). 19 recipes, merchants with faction-modified prices.
* **Story & quests:** 12-stage main quest (burned Ashenvale → Banner trail → court intrigue → Fort Cinderwatch boss → Spire prophecy → 3 shards via glide/updraft/cave puzzle → Hollow Rift boss → **4 endings**), 9 side quests, 4 companion quests, 2 hidden chains (Glimmerstag; 12 lore pages), exploration discoveries (XP, journal, map).
* **Factions:** 6 factions with reputation that changes prices, shop access, audiences (palace barred below −60), dialogue and which endings are available.
* **Companions:** Lyra, Brann, Iselle, Kestrel — recruit up to 2, distinct combat roles, loyalty that reacts to your faction choices, barks about places/time, personal quests. Companions never die (they retreat).
* **Presentation:** procedural humanoid rig with blended animation (breathing, idle variations, blinking, eye/head look-at, expressions, talk mouth, walk/run/sprint/crouch/swim/ride/glide/jump/land, roll, attack combos, cast, block, sit, work, carry, pickup, interact, emotes), creature animation (gaits, grazing, resting, ear twitches), weather (rain, snow, fog, storm + lightning), clouds, stars, chimney smoke, campfires, flickering torch light pool, waving banners.
* **UI/UX:** consistent rounded-corner medieval theme; hover/press/focus/disabled states, tab transitions, tooltips, toasts, compass with quest/waypoint, minimap, boss bars, map with fast travel & waypoints, journal, confirmation dialogs, loading screen. Accessibility: UI scale, high contrast, subtitles, text size, reduce-motion, tutorial hints, remappable keys, sensitivity, dead-zone, vibration.
* **Audio:** generative music that crossfades by mood (menu, day, night, village, city, mountain, coast, ruin, cave, rift, combat, story) without restarting on menus; layered ambience (wind, rain, water, crowd, birds, crickets, cave drips, fire, thunder); ~60 SFX incl. surface-aware footsteps, UI sounds, per-element spells; dialogue blips; 5 volume buses + mute, saved.

## Architecture
```
src/game/data.ts        static content (classes, items, skills, quests, dialogue, presets…)
src/game/store.ts       reactive state, saves (versioned, validated), quests, dialogue VM, inventory, progression
src/game/audio.ts       WebAudio synthesis + buses
src/game/world.ts       noise terrain, rivers, textures, instanced vegetation (chunked, culled, wind shader)
src/game/structures.ts  buildings/walls/castle/landmarks baked into merged meshes + colliders
src/game/interiors.ts   furniture + interior builders
src/game/rigs.ts        humanoid / creature / bird rigs + animation
src/game/fx.ts          sky, lights, seasons, weather, particles, torch pool, floating text
src/game/actors.ts      NPC schedules, wildlife, enemies, bosses, companions, remote players
src/game/game.ts        engine: input, player controller, combat, interactions, housing, mounts, loop
src/game/net.ts         PeerJS multiplayer
src/ui/*.tsx            React UI (menus, creator, HUD, codex, panels, settings)
tests/*.ts(x)           headless tests (see below)
```
Dependencies: `three`, `peerjs`, `react`, `tailwindcss` (+ vite). No other runtime deps; all art/audio generated in code.
Performance techniques: merged static meshes, chunked InstancedMesh with frustum + distance culling, density scaling per preset (instance `count`), shadow-camera snapping, pooled lights (≤8), distance-based NPC/animal simulation + visibility, particles in 3 pooled `Points`, render-scale per preset.

## Saves
`localStorage`: `aetherfall.save.auto|1|2|3` (JSON, `{v, ts, summary, d}`) and `aetherfall.settings`. Saves are validated on read; a corrupt/invalid slot is moved to `<slot>.corrupt` (never silently deleted) and treated as empty; missing fields are merged with defaults (migration hook via `v`). Autosave every 90 s, on sleeping, and when quitting to menu.

## Combat (new, self-contained)
LMB combo (3 hits, weapon-dependent reach/speed), bows fire arrows, staves fire bound-element bolts, RMB block (stamina), Q dodge roll with i-frames, 4 hot-bar abilities (costs, cooldowns, AoE/projectile/chain/line/cone/blink/meteor/heal/buff), enemy wind-up telegraphs, boss shockwaves/volleys/summons.

## Tests & results (all in `tests/`, run `bash tests/run.sh`)
| Suite | What it checks | Result |
|---|---|---|
| `logic.test.ts` | 553 data-integrity & logic checks: all 10 classes, every item/recipe/shop/quest/dialogue reference, quest chain through dialogue, reputation/prices, equip/use/level/skills, save/load, corrupt-save recovery | **553 / 553 pass** (it caught a real double-advance quest bug, fixed) |
| `world.test.ts` | headless world gen (terrain, settlements, 97k plants, every interior, every rig/animation state, 94 NPCs, 227 creatures, 120 frames of weather/sky/AI, enemy aggro/death) | **pass**, ~1.4 s CPU generation |
| `ui.test.tsx` | server-renders 35 screens/tabs (HUD, 9 codex tabs, menus, creator, dialogues, shops, housing, MP, settings, whole `<App/>`) | **35 / 35 render** |
| `play.test.ts` | runs the **real game loop** (stubbed GL): boot, WASD/sprint, jump, **glide**, melee/ability/dodge/damage/kill, NPC dialogue→quest, enter/leave tavern, buy/furnish/upgrade/store in a home, mount/dismount, cave & Hollow Rift with enemies, hotkeys, pause, death/respawn, 4 000 frames of day/weather, save → reload → restart | **53 / 53 pass** |
*Not tested:* real GPU rendering, frame rate, Chromebook/Firefox/Edge, physical gamepads, two-machine multiplayer, audio output.

## Known limitations / remaining work
* Visuals & performance unverified on real hardware (largest risk). Presets are the tuning lever; **Low** is the safest on Chromebooks.
* No real climbing/mantling/balancing, crossbow is bow-class, no occlusion culling or texture compression/streaming (everything is procedural & in memory).
* NPC navigation is waypoint steering with stuck-recovery (no navmesh); NPCs are not attackable; guards do not turn hostile.
* Furniture is placed in front of the player (Move/Rotate/Store), not free-drag; you cannot enter other players' homes; multiplayer does not sync combat, quest or housing state.
* Companion dialogue is limited to recruitment, quest and ambient barks; no romance or betrayal events yet. Political "leadership" is represented by the four endings.
* Wildlife is passive/hostile only (no predator-prey chases between animals). Voice acting does not exist (blips only).
* Weather affects fog, audio, NPC routines, creatures' visibility; deeper ecosystem reactions are not implemented.

## Task list
**Done:** creator + 10 classes, world, settlements, interiors, housing, multiplayer, wildlife, vegetation, 6 presets, seasons/weather, NPC routines, mounts, companions, factions, professions, quests/endings, audio, controller + remapping, saves, accessibility, automated tests.
**Remaining / next:** real-hardware profiling & art pass, climbing/mantle, navmesh, more quests/regions, companion romance/betrayal arcs, player-home visits in MP, recorded audio.
